#if defined(BMI160GEN_USE_CURIEIMU)
// Arduino/Genuino 101
#include "internal/ss_spi_101.cpp"

#endif
